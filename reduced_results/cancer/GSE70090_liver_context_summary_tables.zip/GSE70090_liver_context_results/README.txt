GSE70090 liver normal-tumor sequence-context results.
BS measures bisulfite-resistant 5mC+5hmC; oxBS is used as an approximation of 5mC.
BS-minus-oxBS motif summaries are exploratory proxies for 5hmC and are not site-matched estimates.
Primary coverage threshold: >=10x.
Upload this entire folder as a ZIP to ChatGPT.
