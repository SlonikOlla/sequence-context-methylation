CpG coverage-stratified sequence-context analysis
Coverage strata: 10-14x, 15-19x, 20-29x, >=30x, plus ALL_10plus.
Promoter: strand-aware TSS -2000/+500 bp.
Primary hierarchy: CpG island > promoter > CDS > exon > genic > intergenic.
ZIP this folder and upload it to ChatGPT.
