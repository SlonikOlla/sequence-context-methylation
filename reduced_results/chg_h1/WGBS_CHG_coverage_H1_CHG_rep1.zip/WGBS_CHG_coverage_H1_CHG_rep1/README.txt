CHG coverage-stratified sequence-context analysis
Coverage strata: 10-14x, 15-19x, 20-29x, >=30x, plus ALL_10plus.
ZIP this folder and upload it to ChatGPT.
